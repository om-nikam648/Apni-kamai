// Apni-Kamai Trading Platform JavaScript

class TradingPlatform {
    constructor() {
        this.stockData = {
            "RELIANCE": {"price": 2456.75, "change": 23.45, "changePercent": 0.96, "volume": 12543234, "high": 2478.20, "low": 2432.10},
            "TCS": {"price": 3842.30, "change": -15.25, "changePercent": -0.39, "volume": 8234567, "high": 3865.45, "low": 3835.60},
            "INFY": {"price": 1654.80, "change": 8.90, "changePercent": 0.54, "volume": 15678923, "high": 1668.75, "low": 1648.30},
            "HDFC": {"price": 1546.25, "change": -12.35, "changePercent": -0.79, "volume": 9876543, "high": 1562.45, "low": 1540.10},
            "ICICIBANK": {"price": 845.60, "change": 5.75, "changePercent": 0.68, "volume": 18765432, "high": 851.20, "low": 842.15},
            "WIPRO": {"price": 432.15, "change": -2.45, "changePercent": -0.56, "volume": 11234567, "high": 436.80, "low": 430.25},
            "BHARTIARTL": {"price": 976.40, "change": 18.25, "changePercent": 1.90, "volume": 7654321, "high": 982.15, "low": 968.30},
            "LT": {"price": 3245.80, "change": 45.60, "changePercent": 1.43, "volume": 4567890, "high": 3267.25, "low": 3238.45},
            "SBIN": {"price": 623.75, "change": -8.15, "changePercent": -1.29, "volume": 23456789, "high": 634.20, "low": 621.40},
            "ITC": {"price": 456.30, "change": 3.25, "changePercent": 0.72, "volume": 19876543, "high": 459.85, "low": 454.10}
        };

        this.portfolioData = {
            "totalValue": 2456789,
            "totalPnL": 156789,
            "totalPnLPercent": 6.82,
            "dayPnL": 12345,
            "dayPnLPercent": 0.51,
            "holdings": [
                {"symbol": "RELIANCE", "quantity": 50, "avgPrice": 2400.00, "currentPrice": 2456.75, "pnl": 2837.50, "pnlPercent": 2.36},
                {"symbol": "TCS", "quantity": 25, "avgPrice": 3800.00, "currentPrice": 3842.30, "pnl": 1057.50, "pnlPercent": 1.11},
                {"symbol": "INFY", "quantity": 75, "avgPrice": 1600.00, "currentPrice": 1654.80, "pnl": 4110.00, "pnlPercent": 3.43},
                {"symbol": "HDFC", "quantity": 40, "avgPrice": 1580.00, "currentPrice": 1546.25, "pnl": -1350.00, "pnlPercent": -2.14},
                {"symbol": "ICICIBANK", "quantity": 100, "avgPrice": 820.00, "currentPrice": 845.60, "pnl": 2560.00, "pnlPercent": 3.12}
            ]
        };

        this.strategies = [
            {"id": 1, "name": "MA Crossover Strategy", "type": "moving_average", "status": "active", "returns": 8.5, "trades": 23},
            {"id": 2, "name": "RSI Momentum", "type": "rsi", "status": "paused", "returns": -2.1, "trades": 15},
            {"id": 3, "name": "Bollinger Bands", "type": "bollinger", "status": "active", "returns": 12.3, "trades": 31}
        ];

        this.orders = [
            {"id": 1, "symbol": "RELIANCE", "side": "BUY", "quantity": 10, "price": 2450.00, "status": "EXECUTED", "timestamp": "2025-08-11T10:30:00Z"},
            {"id": 2, "symbol": "TCS", "side": "SELL", "quantity": 5, "price": 3840.00, "status": "PENDING", "timestamp": "2025-08-11T11:15:00Z"},
            {"id": 3, "symbol": "INFY", "side": "BUY", "quantity": 25, "price": 1650.00, "status": "EXECUTED", "timestamp": "2025-08-11T09:45:00Z"}
        ];

        this.marketIndices = [
            {"name": "NIFTY 50", "value": 24567.85, "change": 123.45, "changePercent": 0.51},
            {"name": "SENSEX", "value": 80123.67, "change": -234.12, "changePercent": -0.29},
            {"name": "BANK NIFTY", "value": 52345.23, "change": 456.78, "changePercent": 0.88}
        ];

        this.chatHistory = [];
        this.charts = {};
        this.currentPage = 'dashboard';
        
        // Initialize after DOM is loaded
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => this.init());
        } else {
            this.init();
        }
    }

    init() {
        this.setupNavigation();
        this.setupEventListeners();
        this.loadDashboard();
        this.startRealTimeUpdates();
    }

    setupNavigation() {
        const navButtons = document.querySelectorAll('.nav-btn');
        const pages = document.querySelectorAll('.page');

        navButtons.forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                
                const targetPage = btn.getAttribute('data-page');
                console.log('Navigating to:', targetPage); // Debug log
                
                // Update active nav button
                navButtons.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                
                // Show target page
                pages.forEach(page => {
                    page.classList.remove('active');
                    if (page.id === targetPage) {
                        page.classList.add('active');
                        console.log('Activated page:', page.id); // Debug log
                    }
                });

                this.currentPage = targetPage;
                
                // Load page-specific content
                this.loadPageContent(targetPage);
            });
        });
    }

    setupEventListeners() {
        // Stock search
        document.addEventListener('input', (e) => {
            if (e.target && e.target.id === 'stockSearch') {
                this.searchStock(e.target.value);
            }
        });

        // Order form
        document.addEventListener('submit', (e) => {
            if (e.target && e.target.id === 'orderForm') {
                e.preventDefault();
                this.placeOrder();
            }
        });

        // Order type change
        document.addEventListener('change', (e) => {
            if (e.target && e.target.id === 'orderType') {
                const priceGroup = document.getElementById('priceGroup');
                if (priceGroup) {
                    if (e.target.value === 'LIMIT') {
                        priceGroup.style.display = 'block';
                    } else {
                        priceGroup.style.display = 'none';
                    }
                }
            }
        });

        // Strategy builder
        document.addEventListener('click', (e) => {
            if (e.target && e.target.id === 'createStrategyBtn') {
                e.preventDefault();
                this.showStrategyModal();
            }
            
            if (e.target && e.target.id === 'closeModal') {
                e.preventDefault();
                this.hideStrategyModal();
            }
            
            if (e.target && e.target.id === 'cancelStrategy') {
                e.preventDefault();
                this.hideStrategyModal();
            }

            if (e.target && e.target.id === 'sendMessage') {
                e.preventDefault();
                this.sendChatMessage();
            }
        });

        // Strategy type change
        document.addEventListener('change', (e) => {
            if (e.target && e.target.id === 'strategyType') {
                this.updateStrategyParams(e.target.value);
            }
        });

        // Strategy form
        document.addEventListener('submit', (e) => {
            if (e.target && e.target.id === 'strategyForm') {
                e.preventDefault();
                this.saveStrategy();
            }
        });

        // Backtest form
        document.addEventListener('submit', (e) => {
            if (e.target && e.target.id === 'backtestForm') {
                e.preventDefault();
                this.runBacktest();
            }
        });

        // Chat input
        document.addEventListener('keypress', (e) => {
            if (e.target && e.target.id === 'chatInput' && e.key === 'Enter') {
                e.preventDefault();
                this.sendChatMessage();
            }
        });

        // Quick actions
        document.addEventListener('click', (e) => {
            if (e.target && e.target.closest('.quick-actions') && e.target.hasAttribute('data-question')) {
                const question = e.target.getAttribute('data-question');
                this.sendChatMessage(question);
            }
        });

        // Modal backdrop click
        document.addEventListener('click', (e) => {
            if (e.target && e.target.classList.contains('modal')) {
                this.hideStrategyModal();
            }
        });
    }

    loadPageContent(page) {
        console.log('Loading content for page:', page); // Debug log
        
        switch(page) {
            case 'dashboard':
                setTimeout(() => this.loadDashboard(), 100);
                break;
            case 'trading':
                setTimeout(() => this.loadTrading(), 100);
                break;
            case 'portfolio':
                setTimeout(() => this.loadPortfolio(), 100);
                break;
            case 'strategies':
                setTimeout(() => this.loadStrategies(), 100);
                break;
            case 'backtesting':
                setTimeout(() => this.loadBacktesting(), 100);
                break;
            case 'learn':
                setTimeout(() => this.loadLearn(), 100);
                break;
            case 'rancho':
                setTimeout(() => this.loadRancho(), 100);
                break;
        }
    }

    loadDashboard() {
        this.updateMarketIndices();
        this.updateStockMovers();
        this.updateRecentOrders();
        setTimeout(() => this.createPortfolioChart(), 200);
    }

    updateMarketIndices() {
        const container = document.getElementById('marketIndices');
        if (!container) return;

        container.innerHTML = this.marketIndices.map(index => `
            <div class="market-index">
                <div>
                    <div class="index-name">${index.name}</div>
                    <div class="index-value">${this.formatNumber(index.value)}</div>
                </div>
                <div class="index-change ${index.change >= 0 ? 'positive' : 'negative'}">
                    ${index.change >= 0 ? '+' : ''}${this.formatNumber(index.change)} (${index.changePercent >= 0 ? '+' : ''}${index.changePercent}%)
                </div>
            </div>
        `).join('');
    }

    updateStockMovers() {
        const container = document.getElementById('stockMovers');
        if (!container) return;

        const sortedStocks = Object.entries(this.stockData)
            .sort((a, b) => Math.abs(b[1].changePercent) - Math.abs(a[1].changePercent))
            .slice(0, 5);

        container.innerHTML = sortedStocks.map(([symbol, data]) => `
            <div class="stock-mover">
                <div>
                    <div class="stock-symbol">${symbol}</div>
                    <div class="stock-price">₹${this.formatNumber(data.price)}</div>
                </div>
                <div class="stock-change ${data.change >= 0 ? 'positive' : 'negative'}">
                    ${data.change >= 0 ? '+' : ''}${this.formatNumber(data.change)} (${data.changePercent >= 0 ? '+' : ''}${data.changePercent}%)
                </div>
            </div>
        `).join('');
    }

    updateRecentOrders() {
        const container = document.getElementById('recentOrders');
        if (!container) return;

        container.innerHTML = `
            <table>
                <thead>
                    <tr>
                        <th>Symbol</th>
                        <th>Side</th>
                        <th>Quantity</th>
                        <th>Price</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    ${this.orders.map(order => `
                        <tr>
                            <td>${order.symbol}</td>
                            <td>${order.side}</td>
                            <td>${order.quantity}</td>
                            <td>₹${this.formatNumber(order.price)}</td>
                            <td><span class="order-status ${order.status.toLowerCase()}">${order.status}</span></td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `;
    }

    createPortfolioChart() {
        const ctx = document.getElementById('portfolioChart');
        if (!ctx) return;

        const labels = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug'];
        const data = [2200000, 2150000, 2300000, 2250000, 2400000, 2350000, 2420000, 2456789];

        if (this.charts.portfolio) {
            this.charts.portfolio.destroy();
        }

        this.charts.portfolio = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Portfolio Value',
                    data: data,
                    borderColor: '#1FB8CD',
                    backgroundColor: 'rgba(31, 184, 205, 0.1)',
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: false,
                        ticks: {
                            callback: function(value) {
                                return '₹' + (value / 100000).toFixed(0) + 'L';
                            }
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        });
    }

    loadTrading() {
        this.updateCurrentPositions();
        this.updateOrderBook();
    }

    searchStock(query) {
        const stockQuote = document.getElementById('stockQuote');
        if (!stockQuote || !query) {
            if (stockQuote) stockQuote.innerHTML = '';
            return;
        }

        const symbol = query.toUpperCase();
        const stock = this.stockData[symbol];
        
        if (stock) {
            stockQuote.innerHTML = `
                <div class="quote-symbol">${symbol}</div>
                <div class="quote-price">
                    ₹${this.formatNumber(stock.price)}
                    <span class="quote-change ${stock.change >= 0 ? 'positive' : 'negative'}">
                        ${stock.change >= 0 ? '+' : ''}${this.formatNumber(stock.change)} (${stock.changePercent >= 0 ? '+' : ''}${stock.changePercent}%)
                    </span>
                </div>
                <div class="quote-details">
                    <div class="quote-detail">
                        <div class="quote-detail-label">High</div>
                        <div class="quote-detail-value">₹${this.formatNumber(stock.high)}</div>
                    </div>
                    <div class="quote-detail">
                        <div class="quote-detail-label">Low</div>
                        <div class="quote-detail-value">₹${this.formatNumber(stock.low)}</div>
                    </div>
                    <div class="quote-detail">
                        <div class="quote-detail-label">Volume</div>
                        <div class="quote-detail-value">${this.formatNumber(stock.volume)}</div>
                    </div>
                </div>
            `;
        } else {
            stockQuote.innerHTML = '<p>Stock not found. Try: RELIANCE, TCS, INFY, HDFC, ICICIBANK</p>';
        }
    }

    updateCurrentPositions() {
        const container = document.getElementById('currentPositions');
        if (!container) return;

        container.innerHTML = `
            <table>
                <thead>
                    <tr>
                        <th>Symbol</th>
                        <th>Quantity</th>
                        <th>Avg Price</th>
                        <th>Current Price</th>
                        <th>P&L</th>
                    </tr>
                </thead>
                <tbody>
                    ${this.portfolioData.holdings.map(holding => `
                        <tr>
                            <td>${holding.symbol}</td>
                            <td>${holding.quantity}</td>
                            <td>₹${this.formatNumber(holding.avgPrice)}</td>
                            <td>₹${this.formatNumber(holding.currentPrice)}</td>
                            <td class="${holding.pnl >= 0 ? 'pnl-positive' : 'pnl-negative'}">
                                ₹${this.formatNumber(holding.pnl)} (${holding.pnlPercent >= 0 ? '+' : ''}${holding.pnlPercent}%)
                            </td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `;
    }

    updateOrderBook() {
        const container = document.getElementById('orderBook');
        if (!container) return;

        container.innerHTML = `
            <table>
                <thead>
                    <tr>
                        <th>Bid</th>
                        <th>Ask</th>
                        <th>Volume</th>
                    </tr>
                </thead>
                <tbody>
                    <tr><td>₹2,456.00</td><td>₹2,456.75</td><td>1,250</td></tr>
                    <tr><td>₹2,455.50</td><td>₹2,457.25</td><td>2,100</td></tr>
                    <tr><td>₹2,455.00</td><td>₹2,457.75</td><td>850</td></tr>
                    <tr><td>₹2,454.50</td><td>₹2,458.25</td><td>1,750</td></tr>
                    <tr><td>₹2,454.00</td><td>₹2,458.75</td><td>950</td></tr>
                </tbody>
            </table>
        `;
    }

    placeOrder() {
        const symbol = document.getElementById('orderSymbol')?.value;
        const side = document.getElementById('orderSide')?.value;
        const quantity = parseInt(document.getElementById('orderQuantity')?.value || 0);
        const orderType = document.getElementById('orderType')?.value;
        const price = orderType === 'LIMIT' ? parseFloat(document.getElementById('orderPrice')?.value || 0) : null;

        if (!symbol || !quantity) {
            this.showToast('Please fill in all required fields', 'error');
            return;
        }

        const order = {
            id: this.orders.length + 1,
            symbol,
            side,
            quantity,
            price: price || this.stockData[symbol]?.price || 0,
            status: 'EXECUTED',
            timestamp: new Date().toISOString()
        };

        this.orders.unshift(order);
        this.showToast(`Order placed: ${side} ${quantity} ${symbol}`, 'success');
        
        // Reset form
        const form = document.getElementById('orderForm');
        if (form) form.reset();
        const priceGroup = document.getElementById('priceGroup');
        if (priceGroup) priceGroup.style.display = 'none';
        
        // Update recent orders if on dashboard
        this.updateRecentOrders();
    }

    loadPortfolio() {
        this.updateHoldingsTable();
        setTimeout(() => {
            this.createAllocationChart();
            this.createPerformanceChart();
        }, 200);
    }

    updateHoldingsTable() {
        const container = document.getElementById('holdingsTable');
        if (!container) return;

        container.innerHTML = `
            <table>
                <thead>
                    <tr>
                        <th>Symbol</th>
                        <th>Quantity</th>
                        <th>Avg Price</th>
                        <th>Current Price</th>
                        <th>Market Value</th>
                        <th>P&L</th>
                        <th>P&L %</th>
                    </tr>
                </thead>
                <tbody>
                    ${this.portfolioData.holdings.map(holding => `
                        <tr>
                            <td>${holding.symbol}</td>
                            <td>${holding.quantity}</td>
                            <td>₹${this.formatNumber(holding.avgPrice)}</td>
                            <td>₹${this.formatNumber(holding.currentPrice)}</td>
                            <td>₹${this.formatNumber(holding.quantity * holding.currentPrice)}</td>
                            <td class="${holding.pnl >= 0 ? 'pnl-positive' : 'pnl-negative'}">
                                ₹${this.formatNumber(holding.pnl)}
                            </td>
                            <td class="${holding.pnl >= 0 ? 'pnl-positive' : 'pnl-negative'}">
                                ${holding.pnlPercent >= 0 ? '+' : ''}${holding.pnlPercent}%
                            </td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `;
    }

    createAllocationChart() {
        const ctx = document.getElementById('allocationChart');
        if (!ctx) return;

        const holdings = this.portfolioData.holdings;
        const labels = holdings.map(h => h.symbol);
        const data = holdings.map(h => h.quantity * h.currentPrice);
        const colors = ['#1FB8CD', '#FFC185', '#B4413C', '#ECEBD5', '#5D878F'];

        if (this.charts.allocation) {
            this.charts.allocation.destroy();
        }

        this.charts.allocation = new Chart(ctx, {
            type: 'pie',
            data: {
                labels: labels,
                datasets: [{
                    data: data,
                    backgroundColor: colors,
                    borderWidth: 2,
                    borderColor: '#fff'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const value = context.raw;
                                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                const percentage = ((value / total) * 100).toFixed(1);
                                return `${context.label}: ₹${value.toLocaleString()} (${percentage}%)`;
                            }
                        }
                    }
                }
            }
        });
    }

    createPerformanceChart() {
        const ctx = document.getElementById('performanceChart');
        if (!ctx) return;

        const labels = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug'];
        const data = [2200000, 2150000, 2300000, 2250000, 2400000, 2350000, 2420000, 2456789];

        if (this.charts.performance) {
            this.charts.performance.destroy();
        }

        this.charts.performance = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Portfolio Value',
                    data: data,
                    borderColor: '#1FB8CD',
                    backgroundColor: 'rgba(31, 184, 205, 0.1)',
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: false,
                        ticks: {
                            callback: function(value) {
                                return '₹' + (value / 100000).toFixed(0) + 'L';
                            }
                        }
                    }
                }
            }
        });
    }

    loadStrategies() {
        this.updateStrategiesList();
        this.updateBacktestStrategyOptions();
    }

    updateStrategiesList() {
        const container = document.getElementById('strategiesList');
        if (!container) return;

        container.innerHTML = this.strategies.map(strategy => `
            <div class="strategy-card">
                <div class="strategy-header">
                    <h4 class="strategy-name">${strategy.name}</h4>
                    <span class="strategy-status ${strategy.status}">${strategy.status}</span>
                </div>
                <div class="strategy-metrics">
                    <div class="strategy-metric">
                        <div class="strategy-metric-label">Returns</div>
                        <div class="strategy-metric-value ${strategy.returns >= 0 ? 'pnl-positive' : 'pnl-negative'}">
                            ${strategy.returns >= 0 ? '+' : ''}${strategy.returns}%
                        </div>
                    </div>
                    <div class="strategy-metric">
                        <div class="strategy-metric-label">Trades</div>
                        <div class="strategy-metric-value">${strategy.trades}</div>
                    </div>
                </div>
                <div class="strategy-actions">
                    <button class="btn btn--sm btn--secondary" onclick="app.toggleStrategy(${strategy.id})">
                        ${strategy.status === 'active' ? 'Pause' : 'Start'}
                    </button>
                    <button class="btn btn--sm btn--outline" onclick="app.cloneStrategy(${strategy.id})">Clone</button>
                    <button class="btn btn--sm btn--outline" onclick="app.deleteStrategy(${strategy.id})">Delete</button>
                </div>
            </div>
        `).join('');
    }

    showStrategyModal() {
        const modal = document.getElementById('strategyModal');
        if (modal) {
            modal.classList.remove('hidden');
            this.updateStrategyParams('moving_average');
        }
    }

    hideStrategyModal() {
        const modal = document.getElementById('strategyModal');
        if (modal) {
            modal.classList.add('hidden');
            const form = document.getElementById('strategyForm');
            if (form) form.reset();
        }
    }

    updateStrategyParams(type) {
        const container = document.getElementById('strategyParams');
        if (!container) return;

        let paramsHtml = '';

        switch(type) {
            case 'moving_average':
                paramsHtml = `
                    <h4>Moving Average Parameters</h4>
                    <div class="param-group">
                        <div class="form-group">
                            <label class="form-label">Short MA Period</label>
                            <input type="number" class="form-control" value="10" min="1" max="200">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Long MA Period</label>
                            <input type="number" class="form-control" value="20" min="1" max="200">
                        </div>
                    </div>
                `;
                break;
            case 'rsi':
                paramsHtml = `
                    <h4>RSI Parameters</h4>
                    <div class="param-group">
                        <div class="form-group">
                            <label class="form-label">RSI Period</label>
                            <input type="number" class="form-control" value="14" min="1" max="100">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Overbought Level</label>
                            <input type="number" class="form-control" value="70" min="50" max="100">
                        </div>
                    </div>
                    <div class="param-group">
                        <div class="form-group">
                            <label class="form-label">Oversold Level</label>
                            <input type="number" class="form-control" value="30" min="0" max="50">
                        </div>
                    </div>
                `;
                break;
            case 'bollinger':
                paramsHtml = `
                    <h4>Bollinger Bands Parameters</h4>
                    <div class="param-group">
                        <div class="form-group">
                            <label class="form-label">Period</label>
                            <input type="number" class="form-control" value="20" min="1" max="100">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Standard Deviations</label>
                            <input type="number" class="form-control" value="2" min="1" max="5" step="0.1">
                        </div>
                    </div>
                `;
                break;
            case 'custom':
                paramsHtml = `
                    <h4>Custom Strategy Code</h4>
                    <div class="form-group">
                        <label class="form-label">Strategy Logic</label>
                        <textarea class="form-control" rows="6" placeholder="Enter your custom strategy logic here..."></textarea>
                    </div>
                `;
                break;
        }

        container.innerHTML = paramsHtml;
    }

    saveStrategy() {
        const name = document.getElementById('strategyName')?.value;
        const type = document.getElementById('strategyType')?.value;
        const symbol = document.getElementById('strategySymbol')?.value;

        if (!name || !symbol) {
            this.showToast('Please fill in all required fields', 'error');
            return;
        }

        const newStrategy = {
            id: this.strategies.length + 1,
            name,
            type,
            status: 'paused',
            returns: 0,
            trades: 0
        };

        this.strategies.push(newStrategy);
        this.hideStrategyModal();
        this.updateStrategiesList();
        this.showToast('Strategy created successfully', 'success');
    }

    toggleStrategy(id) {
        const strategy = this.strategies.find(s => s.id === id);
        if (strategy) {
            strategy.status = strategy.status === 'active' ? 'paused' : 'active';
            this.updateStrategiesList();
            this.showToast(`Strategy ${strategy.status}`, 'info');
        }
    }

    cloneStrategy(id) {
        const strategy = this.strategies.find(s => s.id === id);
        if (strategy) {
            const cloned = {
                ...strategy,
                id: this.strategies.length + 1,
                name: strategy.name + ' (Copy)',
                status: 'paused',
                returns: 0,
                trades: 0
            };
            this.strategies.push(cloned);
            this.updateStrategiesList();
            this.showToast('Strategy cloned successfully', 'success');
        }
    }

    deleteStrategy(id) {
        this.strategies = this.strategies.filter(s => s.id !== id);
        this.updateStrategiesList();
        this.showToast('Strategy deleted', 'info');
    }

    loadBacktesting() {
        this.updateBacktestStrategyOptions();
    }

    updateBacktestStrategyOptions() {
        const select = document.getElementById('backtestStrategy');
        if (!select) return;

        select.innerHTML = '<option value="">Select Strategy</option>' + 
            this.strategies.map(strategy => 
                `<option value="${strategy.id}">${strategy.name}</option>`
            ).join('');
    }

    runBacktest() {
        const strategyId = document.getElementById('backtestStrategy')?.value;
        const startDate = document.getElementById('backtestStartDate')?.value;
        const endDate = document.getElementById('backtestEndDate')?.value;
        const capital = parseFloat(document.getElementById('initialCapital')?.value || 0);

        if (!strategyId) {
            this.showToast('Please select a strategy', 'error');
            return;
        }

        // Simulate backtest results
        const results = {
            totalReturn: 15.4,
            annualizedReturn: 12.8,
            maxDrawdown: -8.2,
            sharpeRatio: 1.34,
            totalTrades: 47,
            winRate: 64.3,
            finalValue: capital * 1.154
        };

        this.displayBacktestResults(results);
        setTimeout(() => this.createBacktestChart(), 200);
        this.showToast('Backtest completed successfully', 'success');
    }

    displayBacktestResults(results) {
        const container = document.getElementById('backtestResults');
        if (!container) return;

        container.innerHTML = `
            <div class="result-metrics">
                <div class="result-metric">
                    <div class="result-metric-label">Total Return</div>
                    <div class="result-metric-value pnl-positive">${results.totalReturn}%</div>
                </div>
                <div class="result-metric">
                    <div class="result-metric-label">Annual Return</div>
                    <div class="result-metric-value pnl-positive">${results.annualizedReturn}%</div>
                </div>
                <div class="result-metric">
                    <div class="result-metric-label">Max Drawdown</div>
                    <div class="result-metric-value pnl-negative">${results.maxDrawdown}%</div>
                </div>
                <div class="result-metric">
                    <div class="result-metric-label">Sharpe Ratio</div>
                    <div class="result-metric-value">${results.sharpeRatio}</div>
                </div>
                <div class="result-metric">
                    <div class="result-metric-label">Total Trades</div>
                    <div class="result-metric-value">${results.totalTrades}</div>
                </div>
                <div class="result-metric">
                    <div class="result-metric-label">Win Rate</div>
                    <div class="result-metric-value">${results.winRate}%</div>
                </div>
            </div>
        `;
    }

    createBacktestChart() {
        const ctx = document.getElementById('backtestChart');
        if (!ctx) return;

        const labels = Array.from({length: 12}, (_, i) => {
            const date = new Date(2024, i, 1);
            return date.toLocaleDateString('en-US', {month: 'short'});
        });

        const data = [1000000, 1020000, 1050000, 980000, 1100000, 1080000, 1150000, 1120000, 1180000, 1140000, 1200000, 1154000];

        if (this.charts.backtest) {
            this.charts.backtest.destroy();
        }

        this.charts.backtest = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Portfolio Value',
                    data: data,
                    borderColor: '#1FB8CD',
                    backgroundColor: 'rgba(31, 184, 205, 0.1)',
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: false,
                        ticks: {
                            callback: function(value) {
                                return '₹' + (value / 100000).toFixed(0) + 'L';
                            }
                        }
                    }
                }
            }
        });
    }

    loadLearn() {
        // Learn page is static content, no dynamic loading needed
    }

    loadRancho() {
        // Chat is already initialized, no additional loading needed
    }

    sendChatMessage(message = null) {
        const input = document.getElementById('chatInput');
        const messagesContainer = document.getElementById('chatMessages');
        
        const text = message || (input ? input.value.trim() : '');
        if (!text) return;

        // Add user message
        this.addChatMessage(text, 'user');
        
        // Clear input
        if (!message && input) input.value = '';

        // Simulate AI response
        setTimeout(() => {
            const response = this.generateAIResponse(text);
            this.addChatMessage(response, 'bot');
        }, 1000);
    }

    addChatMessage(text, type) {
        const messagesContainer = document.getElementById('chatMessages');
        if (!messagesContainer) return;
        
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${type}-message`;
        
        messageDiv.innerHTML = `
            <div class="message-content">
                <p>${text}</p>
            </div>
        `;
        
        messagesContainer.appendChild(messageDiv);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }

    generateAIResponse(question) {
        const responses = {
            'top gainers': 'Based on today\'s market data, the top gainers are:\n1. BHARTIARTL: +1.90%\n2. LT: +1.43%\n3. RELIANCE: +0.96%\n\nThese stocks are showing strong momentum and might be worth monitoring.',
            'portfolio analysis': 'Your portfolio is performing well with a total return of 6.82%. Key insights:\n• Strong performance from INFY (+3.43%)\n• HDFC showing some weakness (-2.14%)\n• Good diversification across sectors\n• Consider rebalancing if HDFC continues to underperform.',
            'strategy suggestion': 'Given current market conditions, I recommend:\n• Moving Average crossover for trend following\n• RSI strategy for momentum plays\n• Consider defensive positioning due to market volatility\n• Focus on quality stocks with strong fundamentals.',
            'risk analysis': 'Your current portfolio risks:\n• Concentration risk in financial sector\n• HDFC position showing losses\n• Overall portfolio beta appears moderate\n• Consider adding defensive stocks or hedging instruments.'
        };

        for (const [key, response] of Object.entries(responses)) {
            if (question.toLowerCase().includes(key)) {
                return response;
            }
        }

        return 'I can help you with trading analysis, portfolio optimization, strategy development, and market insights. Feel free to ask about specific stocks, market trends, or trading strategies!';
    }

    startRealTimeUpdates() {
        // Reduce update frequency to prevent constant changes
        setInterval(() => {
            if (Math.random() < 0.3) { // Only update 30% of the time
                Object.keys(this.stockData).forEach(symbol => {
                    const stock = this.stockData[symbol];
                    const changePercent = (Math.random() - 0.5) * 0.01; // ±0.5% random change
                    const newPrice = stock.price * (1 + changePercent);
                    const priceChange = newPrice - stock.price;
                    
                    this.stockData[symbol] = {
                        ...stock,
                        price: parseFloat(newPrice.toFixed(2)),
                        change: parseFloat(priceChange.toFixed(2)),
                        changePercent: parseFloat((changePercent * 100).toFixed(2))
                    };
                });

                // Update portfolio data
                this.updatePortfolioFromStockPrices();
                
                // Only update current page
                if (this.currentPage === 'dashboard') {
                    this.updateDashboardData();
                } else if (this.currentPage === 'trading') {
                    this.updateCurrentPositions();
                } else if (this.currentPage === 'portfolio') {
                    this.updateHoldingsTable();
                }
            }
        }, 10000); // Update every 10 seconds
    }

    updatePortfolioFromStockPrices() {
        let totalValue = 0;
        let totalPnL = 0;

        this.portfolioData.holdings.forEach(holding => {
            const currentStock = this.stockData[holding.symbol];
            if (currentStock) {
                holding.currentPrice = currentStock.price;
                const marketValue = holding.quantity * holding.currentPrice;
                const costBasis = holding.quantity * holding.avgPrice;
                holding.pnl = marketValue - costBasis;
                holding.pnlPercent = parseFloat(((holding.pnl / costBasis) * 100).toFixed(2));
                
                totalValue += marketValue;
                totalPnL += holding.pnl;
            }
        });

        this.portfolioData.totalValue = totalValue;
        this.portfolioData.totalPnL = totalPnL;
        this.portfolioData.totalPnLPercent = parseFloat(((totalPnL / (totalValue - totalPnL)) * 100).toFixed(2));
    }

    updateDashboardData() {
        // Update stat cards
        const totalValueEl = document.getElementById('totalValue');
        const totalChangeEl = document.getElementById('totalChange');
        
        if (totalValueEl) {
            totalValueEl.textContent = '₹' + this.formatNumber(this.portfolioData.totalValue);
        }
        
        if (totalChangeEl) {
            totalChangeEl.textContent = `${this.portfolioData.totalPnL >= 0 ? '+' : ''}₹${this.formatNumber(Math.abs(this.portfolioData.totalPnL))} (${this.portfolioData.totalPnLPercent >= 0 ? '+' : ''}${this.portfolioData.totalPnLPercent}%)`;
            totalChangeEl.className = `stat-change ${this.portfolioData.totalPnLPercent >= 0 ? 'positive' : 'negative'}`;
        }

        // Update other dynamic content
        this.updateStockMovers();
    }

    formatNumber(num) {
        return new Intl.NumberFormat('en-IN').format(Math.round(num));
    }

    showToast(message, type = 'info') {
        const container = document.getElementById('toastContainer');
        if (!container) return;
        
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.textContent = message;
        
        container.appendChild(toast);
        
        setTimeout(() => {
            if (toast.parentNode) {
                toast.remove();
            }
        }, 3000);
    }
}

// Initialize the application
const app = new TradingPlatform();